#ifndef UART_H
#define UART_H

#include <stdio.h>

#define Debug printf

void COM1_Init( void);

#endif
